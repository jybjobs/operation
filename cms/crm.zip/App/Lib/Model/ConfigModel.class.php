<?php 
    class SmtpModel extends Model{
	
	} 