<?php
    return array(
	 'SYSTEM_ADMINISTRATOR' => 'The system administrator',
	 'SEND_SUCCESS' => 'Send a success',
	 'SEND' => 'send',
	 'SEND_SUCCESSS' => 'Send success!',
	 'SEND_FAILY' => 'Send failure',
	 'SEND_FAILYS' => 'Send failed!',
	 'ILLEGAL_ACCESS' => 'Illegal access!',
	 'NOT_CHOOSE_ANY_CONTENT' => 'You have not choose any content!',
	 'DELETE_SUCCESS' => 'Deleted successfully!',
	 'DELETE_FAILY' => 'Delete failed!',
	 'PARAMETER_ERROR_DELETE_FALILY'=>'Parameter error,Delete failed!',
	 'PARAMETER_ERROR_CONTCART_ADMINISTRATOR'=>'Parameter error,Parameter error, please contact your administrator!',
	 'COMPLETE' => 'complete',
	 'SHORT_MESSAGE' => 'short message',
	 'SHORT_MESSAGE_VIEW' => 'To view short message',
	 'WRITE_LETTER' => 'write letter',
	 'INBOX' => 'inbox',
	 'OUTBOX' => 'outbox',
	 'CONTENT' => 'content',
	 'CONTENTSS' => 'content:',
	 'THE_SENDER' => 'The sender',
	 'THE_SENDERS' => 'The sender:',
	 'THE_RECIPIENT' => 'The recipient',
	 'SEND_TIME' => 'Send time',
	 'SEND_TIMES' => 'Send time:',
	 'READING_TIME' => 'Reading time',
	 'UNREAD' => 'unread',
	 'MAIL_SYSTEM' => 'Mail system',
	 'WRITE_LETTER_IN' => 'Write letter in',
	 'ARE_YOU_DELETE' => 'Are you sure you want to delete?',
	 'ARE_YOU_DELETE_RECEIVE' => 'Are you sure you want to delete the receive?',
	 'SELECT_THE_RECIPIENT' => 'Select the recipient',
	 'SELECT_ALL' => '*Select all',
	 'CONTENTS' => '*content',
	 'REPLY' => 'reply',
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	);