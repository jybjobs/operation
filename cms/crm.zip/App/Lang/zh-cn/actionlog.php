<?php
	return array(
		'INVALIDATE_PARAMETER'=>'参数错误',
		'OPERATE_LOG'=>'操作日志',
		'DELETE_LOG_SUCCESS'=>'删除日志成功！',
		'DELETE_RELATED_LOG_SUCCESS' =>	'成功删除了相关记录',
		'DELETE_RELATED_LOG_FAILED'  =>	'删除失败',
		'DELETE_FAILED_CONTACT_ADMINISTRATOR'=> '删除失败，联系管理员！',
		'MY_LOG'=>'我的日志',
		'CREATE_TODAY'=>'今天的',
		'CREATE_THIS_WEEK'=>'本周的',
		'CREATE_THIS_MONTH'=>'本月的',
		'VIEW_BY_LOG_CATEGORY'=>'按日志类型查看',
		'FILTER'=>'筛选条件：',
		'ALL_THE_OPERATION'=>'全部操作',
		'EDIT'=>'编辑',
		'OPERATOR'=>'操作人',
		'OPERATING_TIME'=>'操作时间',
		'MODULE'=>'模块',
		'CONTENT'=>	'内容',
		'TIME'=>'时间',
	
	
	);